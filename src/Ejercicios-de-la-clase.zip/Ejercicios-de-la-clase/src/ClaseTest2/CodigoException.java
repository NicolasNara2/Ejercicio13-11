package ClaseTest2;

public class CodigoException extends Exception {
    public CodigoException() {
        System.out.println("Error. Ingrese un codigo valido.");
    }
}
