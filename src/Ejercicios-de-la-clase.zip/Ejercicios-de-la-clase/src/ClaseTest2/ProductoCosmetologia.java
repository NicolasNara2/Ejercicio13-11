package ClaseTest2;

import java.util.Date;

public class ProductoCosmetologia extends Producto {
private String pao;

}
