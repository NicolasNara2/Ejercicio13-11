package ClaseTest2;

import java.util.Date;

public class ProductoComestible extends Producto{
private Date fechaVencimiento;
}
