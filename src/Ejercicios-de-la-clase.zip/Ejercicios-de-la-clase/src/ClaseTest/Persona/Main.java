package ClaseTest.Persona;

import ClaseTest2.Cliente;
import ClaseTest2.Producto;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Cliente cliente1 = new Cliente("Nicolas", "Rivas", "mail@mail.com", 29);
        Cliente cliente2 = new Cliente("Felipe", "Araque", "mail.@mail.com",28);



            }
        }